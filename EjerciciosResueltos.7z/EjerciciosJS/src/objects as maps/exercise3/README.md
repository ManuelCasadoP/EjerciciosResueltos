# As a objects team

¿Has completado el [ejercicio 8 de funciones](../../functions/exercise8/)?. Adapta el código para poder ordenar los corredores del array `chrono` del ejercicio anterior. Pega en [index.js](index.js) tus soluciones del [ejercicio 8 de funciones](../../functions/exercise8/). Sólo deberías de necesitar añadir dos pequeñas funciones:

* `aFasterThanB(runnerA, runnnerB)`
    * Entrega `true` si `runnerB.time` es mayor que `runnerA.time`. En otro caso entrega `false`.
* `bFasterThanA(runnerA, runnnerB)`
    * Entrega `true` si `runnerA.time` es mayor que `runnerB.time`. En otro caso entrega `false`.
