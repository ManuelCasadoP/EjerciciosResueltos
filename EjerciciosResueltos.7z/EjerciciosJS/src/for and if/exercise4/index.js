const numbers = [0,1,2];
let sum = 0;

for (let item of numbers) {
     sum += item;
}

console.log("La suma de los elementos del array es :",sum);
