const numbers = [0,1,2,4,5,9,3,6,7,8];

counter=0; // Put your code here
for (let item of numbers) {
    // Put your code here
    counter++;
}

console.log("El número de elementos del array es ", counter/* Put your code here */)