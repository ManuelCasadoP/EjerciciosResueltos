const numbers = ["Frodo","Gandalf","Turin","Sauron","Saruman","Bilbo"];

// Put your code here

for (let idx=0; idx < numbers.length; idx++) {
    console.log(numbers[idx]);
    
}
