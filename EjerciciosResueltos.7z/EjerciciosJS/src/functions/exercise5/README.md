# Copy or reference.

* Ya has creado una función para buscar el menor número de un array. Vas a modificarla de manera que busque el menor número entre dos determinados índices del array al final del mismo. Hazlo en el [index.js](index.js) creando una función de nombre ```minorInRange```. La función se emplearía de la siguiente manera:
```javascript
const numbers = [11,22,20,24];
const minor = minorInRange(1,3,numbers);
console.log(minor); // -> 20;
```